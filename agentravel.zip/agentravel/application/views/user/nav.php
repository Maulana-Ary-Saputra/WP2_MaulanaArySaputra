		<h5 class="light">Akun Saya</h5>
		<ul class="collection">
			<li class="collection-item"><a href="<?=site_url('user/profile')?>"><i class="material-icons inline-text">settings</i> Ubah Profil </a></li>
			<li class="collection-item"><a href="<?=site_url('user/order')?>"><i class="material-icons inline-text">shopping_cart</i> Pesanan </a></li>
			<li class="collection-item"><a href="<?=site_url('auth/logout')?>"><i class="material-icons inline-text">power_settings_new</i> Keluar </a></li>
		</ul>